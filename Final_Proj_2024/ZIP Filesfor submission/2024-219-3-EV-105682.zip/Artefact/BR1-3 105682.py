#import statements here
import pandas as pd
from statistics import mean
import csv

#function to give a remark on my mood based on avg_mood value

#Take them in as integers, as all inputs default to strings
financial_situation = int(input("On a scale of 1-10 from insufficient to a sufficient amount of money, are you in a stable financial position? "))
physical_wellness = int(input("On a scale of 1-10 from no pain to painful, how is the pain in your head? "))
social_wellbeing = int(input("On a scale of 1-10 from good family relationships to poor family relationships, how is your familial relationships? "))
avg_mood = round(mean([financial_situation,physical_wellness,social_wellbeing]),2)

print("My Average mood today is ", avg_mood)

df = pd.read_csv('MicroBitSound_105682.csv')
print(df)
# Convert 'Timestamp' column to datetime, is it necessary
#df['time (seconds)'] = pd.to_datetime(df['time (seconds)'], errors='coerce')
sound_min = df['sound level'].min()
sound_max = df['sound level'].max()
sound_mean = df['sound level'].mean()
print (sound_min,sound_max,sound_mean, avg_mood)
if not isinstance(sound_min, float):
    sound_min = float(sound_min)
if not isinstance(sound_max, float):
    sound_max = float(sound_max)
if not isinstance(sound_mean, float):
    sound_mean = float(sound_mean)

f = open("BR1-3_results_105682.csv", "a", newline='')
csv = csv.writer(f)

csv.writerow([sound_min, sound_max, sound_mean, avg_mood])
print("", )
f.close()

