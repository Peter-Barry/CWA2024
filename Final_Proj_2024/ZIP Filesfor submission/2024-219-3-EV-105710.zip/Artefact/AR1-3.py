#This program takes three values from a CSV file and compares them to predict a fourth value
# This program then attempts to execute a "Multiple Linear Regression" AR1
# using 3 independent variables and one dependent variable.       AR1
# The program uses input parameters from the user to make a prediction   AR1
# The program the considers a number of WHAT-IF scenarios using the "trained" model AR2
# to make further predictions
# The program then produces the outcomes from above in a graphical format   AR3
# My program is processing a dataset that originates from an embedded system which senses light
# and uses that data along with user input to test/train a model which predicts mood
# Some Standards: All functions will be at the top of the code, All import statements will be at the top of the code

#Import Statements
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
import matplotlib.pyplot as plt

# Prediction function to predict using 3 independent variables and one dependent variable. 
def predict_mood(hours_of_activity, exercise_intensity, peak_energy_level):
    df = pd.DataFrame([[hours_of_activity, exercise_intensity, peak_energy_level]],
                      columns=['Hours_activity', 'Intensity_exercise', 'Peak_energy'])
    return my_model.predict(df)[0]

# read data set 
data = pd.read_csv('AR1-3_Input.csv') # This dataset is a copy of the output from BR1-3, copied so as to create a backup of BR1-3 data

# Define your independent variables (features) and dependent variable (target)
X = data[['Hours_activity', 'Intensity_exercise', 'Peak_energy']]
Y = data['Mood_Score']

# Splitting the dataset into training and test sets
X_train, X_test, Y_train, Y_test = train_test_split(X, Y, test_size=0.2, random_state=0)

# Creating the Linear Regression model
my_model = LinearRegression()

# Fitting the model with the training data
my_model.fit(X_train, Y_train)

# Predicting mood scores for the test set
Y_pred = my_model.predict(X_test)


print("My Multiple Linear Regression Model is now Complete!")

# Making a prediction using the model
# Let the user enter their own 3 parameters
# Note 2 different datatypes
print("")
print("USER CHOOSES 3 FITNESS LEVELS MODE")
hours = int(input("Enter activity hours. Can be any integer from 0-24 "))
sun = float(input("Enter average daily exercise intensity. Can be anything from 1-10 "))
peak = float(input("Enter peak energy level. Can be anything from 0-10 "))

predicted_mood = predict_mood(hours, sun, peak)  # Example values
print("\n The Predicted Mood Score for the values entered is", predicted_mood)

#___________________What If Questions AR2 _________
# WHAT-IF Q1
# What is will your mood be with low values given to the 3 params?
print("-----------------------------------------------------------")
print("WHAT-IF QUESTION 1")
print("Let's test what the mood will be if the activity is very low")

# Low values for all 3 parameters
hours_of_activity = 2
average_exercise = 1
peak_energy = 2

mood_if_lowactivity = predict_mood(hours_of_activity, average_exercise, peak_energy)  # Example values
print("\n The low activity score mood is", mood_if_lowactivity)

# WHAT-IF Q2
# What is will your mood be with high values given to the 3 params?
print("-----------------------------------------------------------")
print("WHAT-IF QUESTION 2")
print("Let's test what the mood will be if daily activity is very high")

# High values for all 3 parameters
hours_of_activity = 10
average_exercise = 6
peak_energy = 8


# Fitting the model with the training data
my_model.fit(X_train, Y_train)

# Predicting mood scores for the test set
Y_pred = my_model.predict(X_test)


print("My Multiple Linear Regression Model is now Complete!")

# Making a prediction using the model
# Let the user enter their own 3 parameters
# Note 2 different datatypes
print("")
print("USER CHOOSES 3 EXERCISE LEVELS MODE")

# Predicting mood scores for the test set
Y_pred = my_model.predict(X_test)


print("My Multiple Linear Regression Model is now Complete!")

# Making a prediction using the model
# Let the user enter their own 3 parameters
# Note 2 different datatypes
print("")
print("USER CHOOSES 3 LIGHT LEVELS MODE")
hours = int(input("Enter activity hours. Can be any integer from 0-24 "))
exercise = float(input("Enter average exercise intensity. Can be anything from 1-800 "))
peak = float(input("Enter peak energy level. Can be anything from 1-800 "))

predicted_mood = predict_mood(hours, exercise, peak)  # Example values
print("\n The Predicted Mood Score for the values entered is", predicted_mood)

#___________________What If Questions AR2 _________
# WHAT-IF Q1
# What is will your mood be with low values given to the 3 params?
print("-----------------------------------------------------------")
print("WHAT-IF QUESTION 3")
print("Let's test what the mood will be if daily exercise is very low")

# Low values for all 3 parameters
hours_of_activity = 2
average_exercise = 1
peak_energy = 2

mood_if_lowactivity = predict_mood(hours_of_activity, average_exercise, peak_energy)  # Example values
print("\n The low activity score mood is", mood_if_lowactivity)

#creating the bar chart
plt.bar(variable_names, values)

# Adding labels and title
plt.xlabel('hours of activity')
plt.ylabel('Average exercise ')
plt.title('Bar Chart of all 2 WHAT-IFs Predictions')

# Show the plot
plt.show()

