#Aislinn Cullen CWA program 
#import statements here
import pandas as pd
from statistics import mean
import csv
import serial
from time import sleep

#Validate my data befoe I write to the output file  BR2
def validate_data(community_min, physical_max, mental_mean):
    if not isinstance(community_min, float):
        community_min = float(community_min)
    if not isinstance(mental_mean, float):
        mental_mean = float(mental_mean)
    if not isinstance(physical_max, float):
        physical_max = float(physical_max)
    return community_min, physical_max, mental_mean


#Take them in as integers, as all inputs default to strings

community_wellness = int(input("On a scale of 1-10 from very bad to amazing, how is your community?"))

physical_wellness = int(input("On a scale of 1-10 from never to everyday, how often do you excercise?"))

mental_wellness = int(input("On a scale of 1-10 from very unhappy and sad to extremely happy, how are you feeling?"))

avg_mood = round(mean([community_wellness,physical_wellness,mental_wellness]),2)

print("My Average mood today is " , avg_mood)
print("                                   ")
print ("Below is my Microbit results (fitness trackers)")

df = pd.read_csv('105710-microbit-data.csv')

print(df)

#Convert 'Timestamp' column to datetime, is it necessary
#df['time (seconds)'] = pd.to_datetime(df['time (seconds)'], errors='coerce')


community_min = df['yes'].min()
physical_max = df['no'].max()
mental_mean = df['sometimes'].mean()
#community_min, physical_max, mental_mean = validate_data(community_min, physical_max, mental_mean)
#print (community_min,physical_max,mental_mean, avg_mood)
f = open("BR1-3_results.csv", "a", newline='')
csver = csv.writer(f)

#csver.writerow([community_min, physical_max, mental_mean, avg_mood])

f.close()
